import 'package:flutter/material.dart';

const Color myOrange = Color(0xFFee7410);
const Color myYellow = Color(0xFFf4ca02);
const Color myBackground = Color(0xFFF6F6F6);
const Color myGris = Color(0xFFF0EFEF);
const Color myGrisFonce = Color(0xFF333333);