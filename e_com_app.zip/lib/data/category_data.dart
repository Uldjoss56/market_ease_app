import 'package:e_com_app/models/category.dart';

List<Category> myCategories = [
  Category(title: 'All', id: 'c0'),
  Category(title: 'Electronique', id: 'c1',img: 'assets/casque.png'),
  Category(title: 'Fashion', id: 'c2',img: 'assets/casque.png'),
  Category(title: 'Food', id: 'c3',img: 'assets/casque.png'),
];
