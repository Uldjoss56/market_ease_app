import 'package:e_com_app/models/article.dart';

List<Article> myArticle = [
  const Article(
    pathToImg: 'assets/msi.png',
    isLike: false,
    price: 800000,
    name: 'MSI gaming laptops',
    likesCount: 10,
    description:
        """Ce ordinateur est très puissant et offre des capacités interessantes pour le gaming, 
        et des activités solicitant une forte performance au nniveau de la carte graphique""",
  ),
  const Article(
    pathToImg: 'assets/msi.png',
    isLike: false,
    price: 800000,
    name: 'MSI gaming laptops',
    likesCount: 10,
    description:
        """Ce ordinateur est très puissant et offre des capacités interessantes pour le gaming, 
        et des activités solicitant une forte performance au nniveau de la carte graphique""",
  ),
  const Article(
    pathToImg: 'assets/msi.png',
    isLike: false,
    price: 800000,
    name: 'MSI gaming laptops',
    likesCount: 10,
    description:
        """Ce ordinateur est très puissant et offre des capacités interessantes pour le gaming, 
        et des activités solicitant une forte performance au nniveau de la carte graphique""",
  ),
  const Article(
    pathToImg: 'assets/msi.png',
    isLike: false,
    price: 800000,
    name: 'MSI gaming laptops',
    likesCount: 10,
    description:
        """Ce ordinateur est très puissant et offre des capacités interessantes pour le gaming, 
        et des activités solicitant une forte performance au nniveau de la carte graphique""",
  ),
];

List<Article> myNewArticle = [
  const Article(
    pathToImg: 'assets/casque.png',
    isLike: false,
    price: 15000,
    name: 'Casque audio',
    likesCount: 10,
    description:
        "Ce casque est génial",
  ),
  const Article(
    pathToImg: 'assets/casque.png',
    isLike: false,
    price: 15000,
    name: 'Casque audio',
    likesCount: 10,
    description:
        "Ce casque est génial",
  ),
  const Article(
    pathToImg: 'assets/casque.png',
    isLike: false,
    price: 15000,
    name: 'Casque audio',
    likesCount: 10,
    description:
        "Ce casque est génial",
  ),
  const Article(
    pathToImg: 'assets/casque.png',
    isLike: false,
    price: 15000,
    name: 'Casque audio',
    likesCount: 10,
    description:
        "Ce casque est génial",
  ),
  
];
