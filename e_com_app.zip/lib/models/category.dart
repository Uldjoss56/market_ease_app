

class Category {
  Category({
    required this.title,
    required this.id,
    this.img,
  });
  final String title;
  final String id;
  final String? img;
}
