import 'package:flutter/material.dart';

const Color myOrange = Color(0xFFee7410);
const Color myOrangeAA = Color(0xAAee7410);
const Color myOrange55 = Color(0x55ee7410);
const Color myOrange22 = Color(0x22ee7410);

const Color myYellow = Color(0xFFf4ca02);
const Color myYellowAA = Color(0xAAf4ca02);
const Color myYellow55 = Color(0x55f4ca02);
const Color myYellow22 = Color(0x22f4ca02);

const Color myBackground = Color(0xFFF6F6F6);

const Color myGris = Color(0xFFF0EFEF);
const Color myGrisAA = Color(0xAAF0EFEF);
const Color myGris55 = Color(0x55F0EFEF);
const Color myGris22 = Color(0x22F0EFEF);

const Color myGrisFonce = Color(0xFF333333);
const Color myGrisFonceAA = Color(0xAA333333);
const Color myGrisFonce55 = Color(0x55333333);
const Color myGrisFonce22 = Color(0x22333333);

const Color myWhite = Color(0xFFFFFFFF);
const Color myWhiteAA = Color(0xAAFFFFFF);
const Color myWhite55 = Color(0x55FFFFFF);
const Color myWhite22 = Color(0x22FFFFFF);
